/*
 * rand.h
 *
 *  Created on: Nov 23, 2020
 *      Author: samf
 */

#ifndef RAND_H_
#define RAND_H_

int request(void);

#endif /* RAND_H_ */
